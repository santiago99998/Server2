# Have angry zombified piglins drop a custom loottable that drops exp and rare drops regardless of the zombified piglin being killed by a player

# <= 1.21.10
execute as @e[type=minecraft:zombified_piglin] if data entity @s AngryAt unless data entity @s {DeathLootTable:"goldfarmfix:angry_zombified_piglin"} run data modify entity @s DeathLootTable set value "goldfarmfix:angry_zombified_piglin"
execute as @e[type=minecraft:zombified_piglin] unless data entity @s AngryAt if data entity @s {DeathLootTable:"goldfarmfix:angry_zombified_piglin"} run data modify entity @s DeathLootTable set value "minecraft:entities/zombified_piglin"

# 1.21.11+
execute as @e[type=minecraft:zombified_piglin] unless data entity @s {angry_end_time:-1L} unless data entity @s {DeathLootTable:"goldfarmfix:angry_zombified_piglin"} run data modify entity @s DeathLootTable set value "goldfarmfix:angry_zombified_piglin"
execute as @e[type=minecraft:zombified_piglin] if data entity @s {angry_end_time:-1L} if data entity @s {DeathLootTable:"goldfarmfix:angry_zombified_piglin"} run data modify entity @s DeathLootTable set value "minecraft:entities/zombified_piglin"

# Since experience can't directly be dropped by loottables, we drop an experience bottle with some custom data and replace it with an actual xp orb here
execute as @e[type=item] if data entity @s Item.components."minecraft:custom_data".zombified_piglin_xp_drop at @s run summon experience_orb ~ ~ ~ {Value:5}
execute as @e[type=item] if data entity @s Item.components."minecraft:custom_data".zombified_piglin_xp_drop run kill @s