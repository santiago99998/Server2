tellraw @s ["",{"text":" "}]
tellraw @s ["",{"text":" "}]
tellraw @s ["",{"text":" "}]
tellraw @s ["",{"text":" "}]

tellraw @s ["",{"text":"§m                                                                                ","color":"dark_gray"}]

tellraw @s ["",{"text":"                         Timber "},{"text":"/","color":"gray"},{"text":" Global Settings            "},{"text":" < ","click_event":{"action":"run_command","command":"function timber:settings/settings1_click"}},{"text":"2/2"},{"text":" > ","click_event":{"action":"run_command","command":"function timber:settings/settings2_click"}}]

tellraw @s ["",{"text":"§m                                                                                ","color":"dark_gray"}]

execute if score wooden_axe timber matches 1.. run tellraw @s ["",{"text":"[ ✔ ]","color":"green","click_event":{"action":"run_command","command":"function timber:settings/toggle/wooden_axe"}},{"text":" Enable Wooden Axe"}]
execute unless score wooden_axe timber matches 1.. run tellraw @s ["",{"text":"[ ❌ ]","color":"red","click_event":{"action":"run_command","command":"function timber:settings/toggle/wooden_axe"}},{"text":" Enable Wooden Axe"}]

execute if score stone_axe timber matches 1.. run tellraw @s ["",{"text":"[ ✔ ]","color":"green","click_event":{"action":"run_command","command":"function timber:settings/toggle/stone_axe"}},{"text":" Enable Stone Axe"}]
execute unless score stone_axe timber matches 1.. run tellraw @s ["",{"text":"[ ❌ ]","color":"red","click_event":{"action":"run_command","command":"function timber:settings/toggle/stone_axe"}},{"text":" Enable Stone Axe"}]

execute if score copper_axe timber matches 1.. run tellraw @s ["",{"text":"[ ✔ ]","color":"green","click_event":{"action":"run_command","command":"function timber:settings/toggle/copper_axe"}},{"text":" Enable Copper Axe"}]
execute unless score copper_axe timber matches 1.. run tellraw @s ["",{"text":"[ ❌ ]","color":"red","click_event":{"action":"run_command","command":"function timber:settings/toggle/copper_axe"}},{"text":" Enable Copper Axe"}]

execute if score iron_axe timber matches 1.. run tellraw @s ["",{"text":"[ ✔ ]","color":"green","click_event":{"action":"run_command","command":"function timber:settings/toggle/iron_axe"}},{"text":" Enable Iron Axe"}]
execute unless score iron_axe timber matches 1.. run tellraw @s ["",{"text":"[ ❌ ]","color":"red","click_event":{"action":"run_command","command":"function timber:settings/toggle/iron_axe"}},{"text":" Enable Iron Axe"}]

execute if score golden_axe timber matches 1.. run tellraw @s ["",{"text":"[ ✔ ]","color":"green","click_event":{"action":"run_command","command":"function timber:settings/toggle/golden_axe"}},{"text":" Enable Golden Axe"}]
execute unless score golden_axe timber matches 1.. run tellraw @s ["",{"text":"[ ❌ ]","color":"red","click_event":{"action":"run_command","command":"function timber:settings/toggle/golden_axe"}},{"text":" Enable Golden Axe"}]

execute if score diamond_axe timber matches 1.. run tellraw @s ["",{"text":"[ ✔ ]","color":"green","click_event":{"action":"run_command","command":"function timber:settings/toggle/diamond_axe"}},{"text":" Enable Diamond Axe"}]
execute unless score diamond_axe timber matches 1.. run tellraw @s ["",{"text":"[ ❌ ]","color":"red","click_event":{"action":"run_command","command":"function timber:settings/toggle/diamond_axe"}},{"text":" Enable Diamond Axe"}]

execute if score netherite_axe timber matches 1.. run tellraw @s ["",{"text":"[ ✔ ]","color":"green","click_event":{"action":"run_command","command":"function timber:settings/toggle/netherite_axe"}},{"text":" Enable Netherite Axe"}]
execute unless score netherite_axe timber matches 1.. run tellraw @s ["",{"text":"[ ❌ ]","color":"red","click_event":{"action":"run_command","command":"function timber:settings/toggle/netherite_axe"}},{"text":" Enable Netherite Axe"}]

execute if score chop_trees timber matches 1.. run tellraw @s ["",{"text":"[ ✔ ]","color":"green","click_event":{"action":"run_command","command":"function timber:settings/toggle/chop_trees"}},{"text":" Chop Trees","hover_event":{"action":"show_text","value":"All kind of trees will get chopped."}}]
execute unless score chop_trees timber matches 1.. run tellraw @s ["",{"text":"[ ❌ ]","color":"red","click_event":{"action":"run_command","command":"function timber:settings/toggle/chop_trees"}},{"text":" Chop Trees","hover_event":{"action":"show_text","value":"All kind of trees will get chopped."}}]

execute if score chop_fungi timber matches 1.. run tellraw @s ["",{"text":"[ ✔ ]","color":"green","click_event":{"action":"run_command","command":"function timber:settings/toggle/chop_fungi"}},{"text":" Chop Fungi","hover_event":{"action":"show_text","value":["",{"text":"Huge fungi (nether trees) as well as huge mushrooms will get chopped."},{"text":"\n\nUse it on your own risk!\nWhen enabled, this datapack can't differentiate between generated fungi and player-placed fungi and therefore can potentially destroy your buildings.","color":"dark_red"}]}}]
execute unless score chop_fungi timber matches 1.. run tellraw @s ["",{"text":"[ ❌ ]","color":"red","click_event":{"action":"run_command","command":"function timber:settings/toggle/chop_fungi"}},{"text":" Chop Fungi","hover_event":{"action":"show_text","value":["",{"text":"Huge fungi (nether trees) as well as huge mushrooms will get chopped."},{"text":"\n\nUse it on your own risk!\nWhen enabled, this datapack can't differentiate between generated fungi and player-placed fungi and therefore can potentially destroy your buildings.","color":"dark_red"}]}}]

execute if score blocks_per_chop timber matches 1 if score slow_chop timber matches 1.. run tellraw @s ["",{"text":"[ ✎ ]","color":"gray","click_event":{"action":"suggest_command","command":"/scoreboard players set blocks_per_chop timber "},"hover_event":{"action":"show_text","value":"Default: 1"}},{"text":" Set Amount of Destroyed Blocks per Chop"},{"text":" (Current: ","color":"gray"},{"score":{"name":"blocks_per_chop","objective":"timber"},"color":"gray"},{"text":")","color":"gray"}]
execute unless score blocks_per_chop timber matches 1 if score slow_chop timber matches 1.. run tellraw @s ["",{"text":"[ ✎ ]","color":"gray","click_event":{"action":"suggest_command","command":"/scoreboard players set blocks_per_chop timber "},"hover_event":{"action":"show_text","value":"Default: 1"}},{"text":" Set Amount of Destroyed Blocks per Chop"},{"text":" (Current: ","color":"gray"},{"score":{"name":"blocks_per_chop","objective":"timber"},"color":"gray"},{"text":")","color":"gray"}]
execute unless score slow_chop timber matches 1.. run tellraw @s ["",{"text":"[ ✎ ]","color":"dark_gray","hover_event":{"action":"show_text","value":"Not active when \"Chop Slowly\" is disabled."}},{"text":" Set Amount of Destroyed Blocks per Chop"}]

execute if score time_between_chops timber matches 1 if score slow_chop timber matches 1.. run tellraw @s ["",{"text":"[ ✎ ]","color":"gray","click_event":{"action":"suggest_command","command":"/scoreboard players set time_between_chops timber "},"hover_event":{"action":"show_text","value":"Default: 1"}},{"text":" Set Time in Ticks Between Chops"},{"text":" (Current: ","color":"gray"},{"score":{"name":"time_between_chops","objective":"timber"},"color":"gray"},{"text":")","color":"gray"}]
execute unless score time_between_chops timber matches 1 if score slow_chop timber matches 1.. run tellraw @s ["",{"text":"[ ✎ ]","color":"gray","click_event":{"action":"suggest_command","command":"/scoreboard players set time_between_chops timber "},"hover_event":{"action":"show_text","value":"Default: 1"}},{"text":" Set Time in Ticks Between Chops"},{"text":" (Current: ","color":"gray"},{"score":{"name":"time_between_chops","objective":"timber"},"color":"gray"},{"text":")","color":"gray"}]
execute unless score slow_chop timber matches 1.. run tellraw @s ["",{"text":"[ ✎ ]","color":"dark_gray","hover_event":{"action":"show_text","value":"Not active when \"Chop Slowly\" is disabled."}},{"text":" Set Time in Ticks Between Chops"}]

execute if score max_tree_size timber matches 555 run tellraw @s ["",{"text":"[ ✎ ]","color":"gray","click_event":{"action":"suggest_command","command":"/scoreboard players set max_tree_size timber "},"hover_event":{"action":"show_text","value":"Default: 555"}},{"text":" Set Max. Tree Size","hover_event":{"action":"show_text","value":"Trees bigger than this set value won't get further processed."}},{"text":" (Current: ","color":"gray"},{"score":{"name":"max_tree_size","objective":"timber"},"color":"gray"},{"text":")","color":"gray"}]
execute unless score max_tree_size timber matches 555 run tellraw @s ["",{"text":"[ ✎ ]","color":"gray","click_event":{"action":"suggest_command","command":"/scoreboard players set max_tree_size timber "},"hover_event":{"action":"show_text","value":"Default: 555"}},{"text":" Set Max. Tree Size","hover_event":{"action":"show_text","value":"Trees bigger than this set value won't get further processed."}},{"text":" (Current: ","color":"gray"},{"score":{"name":"max_tree_size","objective":"timber"},"color":"gray"},{"text":")","color":"gray"}]

execute if score min_leaves_found timber matches 5 run tellraw @s ["",{"text":"[ ✎ ]","color":"gray","click_event":{"action":"suggest_command","command":"/scoreboard players set min_leaves_found timber "},"hover_event":{"action":"show_text","value":"Default: 5"}},{"text":" Set Min. Leaves to Valid a Tree","hover_event":{"action":"show_text","value":"This datapack considers a tree only if it has this set value amount of naturally generated leaves at its trunk.\nFungi will get checked by the amount of cap blocks and additionally a 3×3 big cross on top of the stem."}},{"text":" (Current: ","color":"gray"},{"score":{"name":"min_leaves_found","objective":"timber"},"color":"gray"},{"text":")","color":"gray"}]
execute unless score min_leaves_found timber matches 5 run tellraw @s ["",{"text":"[ ✎ ]","color":"gray","click_event":{"action":"suggest_command","command":"/scoreboard players set min_leaves_found timber "},"hover_event":{"action":"show_text","value":"Default: 5"}},{"text":" Set Min. Leaves to Valid a Tree","hover_event":{"action":"show_text","value":"This datapack considers a tree only if it has this set value amount of naturally generated leaves at its trunk.\nFungi will get checked by the amount of cap blocks and additionally a 3×3 big cross on top of the stem."}},{"text":" (Current: ","color":"gray"},{"score":{"name":"min_leaves_found","objective":"timber"},"color":"gray"},{"text":")","color":"gray"}]

tellraw @s ["",{"text":"§m                                                                                ","color":"dark_gray"}]

function timber:settings/end_of_message